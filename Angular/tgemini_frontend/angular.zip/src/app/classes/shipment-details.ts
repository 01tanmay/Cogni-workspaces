export class ShipmentDetails {

    shipmentNumber: number;
    consumerCode: any;
    serviceLevel: String;
    paymentTerm: String;
    incoTermsCode: String;
    packageType: String;
    continerType: String;
    carrierCode: String;
    modeOfTransport: String;
    ewwCommodity: String;

    constructor() { }

}
