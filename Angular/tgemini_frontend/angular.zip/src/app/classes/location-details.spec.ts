import { LocationDetails } from './location-details';

describe('LocationDetails', () => {
  it('should create an instance', () => {
    expect(new LocationDetails()).toBeTruthy();
  });
});
