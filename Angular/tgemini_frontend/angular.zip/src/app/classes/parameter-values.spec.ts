import { ParameterValues } from './parameter-values';

describe('ParameterValues', () => {
  it('should create an instance', () => {
    expect(new ParameterValues()).toBeTruthy();
  });
});
