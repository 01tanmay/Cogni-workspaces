import { ShipmentDetails } from '../classes/shipment-details';

describe('ShipmentDetails', () => {
  it('should create an instance', () => {
    expect(new ShipmentDetails()).toBeTruthy();
  });
});
