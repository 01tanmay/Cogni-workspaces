export class ShipmentCharges {

    changeCode: Number;
    accountNumber: number;
    userSelInd: String;
    roleCode: number;
    ovrdInd: String;
    ovrdCode: Number;
    amount: String;

    constructor() { }
}
