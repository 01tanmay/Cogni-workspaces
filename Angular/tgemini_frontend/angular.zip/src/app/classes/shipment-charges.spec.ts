import { ShipmentCharges } from './shipment-charges';

describe('ShipmentCharges', () => {
  it('should create an instance', () => {
    expect(new ShipmentCharges()).toBeTruthy();
  });
});
