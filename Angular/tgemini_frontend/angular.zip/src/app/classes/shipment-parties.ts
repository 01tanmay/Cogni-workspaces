export class ShipmentParties {

    accountNumber: number;
    city: String;
    state: String;
    postalCode: number;
    roleCode1: number;
    roleCode2: number;
    shellPA: String;
    quantity: String;

    constructor() { }
}
