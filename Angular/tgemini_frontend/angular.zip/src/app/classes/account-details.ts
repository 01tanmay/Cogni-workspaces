export class AccountDetails {

    ctsAmount: String;
    ctsCurrency: String;
    declaredValue: String;
    declaredValueCurrency: String;
    insuredValue: String;
    insuredValueCurrency: String;
    customsValue: String;
    customsValueCurrency: String
    overrideDimFctrInd: String;
    overrideDimFctr: String

    constructor() { }
}
