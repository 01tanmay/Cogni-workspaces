import { ShipmentParties } from './shipment-parties';

describe('ShipmentParties', () => {
  it('should create an instance', () => {
    expect(new ShipmentParties()).toBeTruthy();
  });
});
