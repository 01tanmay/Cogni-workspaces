import { DateTimeInfo } from './date-time-info';

describe('DateTimeInfo', () => {
  it('should create an instance', () => {
    expect(new DateTimeInfo()).toBeTruthy();
  });
});
