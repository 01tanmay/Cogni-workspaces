export class ShipmentPieces {

    width: number;
    height: number;
    weight: number;
    length: number;
    commodity1: String;
    commodity2: String;
    quantity: number;

    constructor() { }
}
