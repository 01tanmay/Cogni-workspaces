export class ShipmentRatingInfo {

    weightUOM: String;
    dimensionUOM: String;
    volumeUOM: String;
    distanceUOM: String;
    rateTypeOverride: String;

    constructor() { }
}
