import { ShipmentPieces } from './shipment-pieces';

describe('ShipmentPieces', () => {
  it('should create an instance', () => {
    expect(new ShipmentPieces()).toBeTruthy();
  });
});
