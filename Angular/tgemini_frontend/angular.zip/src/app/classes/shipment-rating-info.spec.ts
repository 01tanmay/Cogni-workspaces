import { ShipmentRatingInfo } from './shipment-rating-info';

describe('ShipmentRatingInfo', () => {
  it('should create an instance', () => {
    expect(new ShipmentRatingInfo()).toBeTruthy();
  });
});
